package com.TiendaVHS_RetroVideoManager.Usuarios.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModelUsuarios {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique=true, length = 13, nullable=false)
    private String run;

    @Column(nullable = false)
    private String nombres;

    @Email
    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String apellidos;

    @Column(nullable = true)
    private String telefonoFijo;

    @Column(nullable = false)
    private String direccion;

    @Column(nullable = false)
    private String telefonoMovil;
}
