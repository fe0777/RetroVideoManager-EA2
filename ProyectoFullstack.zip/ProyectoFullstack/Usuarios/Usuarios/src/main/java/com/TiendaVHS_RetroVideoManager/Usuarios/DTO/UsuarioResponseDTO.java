package com.TiendaVHS_RetroVideoManager.Usuarios.DTO;

import lombok.Data;

@Data
public class UsuarioResponseDTO {
    private Long id;
    private String run;
    private String nombres;
    private String email;
    private String apellidos;
    private String telefonoFijo;
    private String direccion;
    private String telefonoMovil;
}
