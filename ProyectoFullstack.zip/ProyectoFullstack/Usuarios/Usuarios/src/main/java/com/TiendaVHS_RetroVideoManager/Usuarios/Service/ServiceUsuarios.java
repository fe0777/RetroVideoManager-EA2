package com.TiendaVHS_RetroVideoManager.Usuarios.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TiendaVHS_RetroVideoManager.Usuarios.DTO.UsuarioRequestDTO;
import com.TiendaVHS_RetroVideoManager.Usuarios.DTO.UsuarioResponseDTO;
import com.TiendaVHS_RetroVideoManager.Usuarios.Model.ModelUsuarios;
import com.TiendaVHS_RetroVideoManager.Usuarios.Repository.RepositoryUsuarios;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ServiceUsuarios {

    @Autowired
    private RepositoryUsuarios repositoryUsuarios;
    
    public List<UsuarioResponseDTO> findAll() {
        return repositoryUsuarios.findAll().stream()
                .map(usuario -> {
                    UsuarioResponseDTO dto = new UsuarioResponseDTO();
                    dto.setId(usuario.getId());
                    dto.setRun(usuario.getRun());
                    dto.setNombres(usuario.getNombres());
                    dto.setEmail(usuario.getEmail());
                    dto.setApellidos(usuario.getApellidos());
                    dto.setTelefonoFijo(usuario.getTelefonoFijo());
                    dto.setDireccion(usuario.getDireccion());
                    dto.setTelefonoMovil(usuario.getTelefonoMovil());
                    return dto;
                })
                .toList();
    }

    public UsuarioResponseDTO findById(Long id) {
        return repositoryUsuarios.findById(id)
                .map(usuario -> {
                    UsuarioResponseDTO dto = new UsuarioResponseDTO();
                    dto.setId(usuario.getId());
                    dto.setRun(usuario.getRun());
                    dto.setNombres(usuario.getNombres());
                    dto.setEmail(usuario.getEmail());
                    dto.setApellidos(usuario.getApellidos());
                    dto.setTelefonoFijo(usuario.getTelefonoFijo());
                    dto.setDireccion(usuario.getDireccion());
                    dto.setTelefonoMovil(usuario.getTelefonoMovil());
                    return dto;
                })
                .orElse(null);
            }

    public void deleteById(Long id) {
        repositoryUsuarios.deleteById(id);
    }

    public UsuarioResponseDTO save(UsuarioRequestDTO Usuario){
        ModelUsuarios nuevoUsuario = new ModelUsuarios();
        nuevoUsuario.setRun(Usuario.getRun());
        nuevoUsuario.setNombres(Usuario.getNombres());
        nuevoUsuario.setEmail(Usuario.getEmail());
        nuevoUsuario.setApellidos(Usuario.getApellidos());
        nuevoUsuario.setTelefonoFijo(Usuario.getTelefonoFijo());
        nuevoUsuario.setDireccion(Usuario.getDireccion());
        nuevoUsuario.setTelefonoMovil(Usuario.getTelefonoMovil());

        return toResponse(repositoryUsuarios.save(nuevoUsuario));
    }

    private UsuarioResponseDTO toResponse(ModelUsuarios usuario) {
        UsuarioResponseDTO dto = new UsuarioResponseDTO();
        dto.setId(usuario.getId());
        dto.setRun(usuario.getRun());
        dto.setNombres(usuario.getNombres());
        dto.setEmail(usuario.getEmail());
        dto.setApellidos(usuario.getApellidos());
        dto.setTelefonoFijo(usuario.getTelefonoFijo());
        dto.setDireccion(usuario.getDireccion());
        dto.setTelefonoMovil(usuario.getTelefonoMovil());
        return dto;
    }

    public UsuarioResponseDTO update(Long id, UsuarioRequestDTO usuario) {
        return repositoryUsuarios.findById(id)
                .map(existingUsuario -> {
                    existingUsuario.setRun(usuario.getRun());
                    existingUsuario.setNombres(usuario.getNombres());
                    existingUsuario.setEmail(usuario.getEmail());
                    existingUsuario.setApellidos(usuario.getApellidos());
                    existingUsuario.setTelefonoFijo(usuario.getTelefonoFijo());
                    existingUsuario.setDireccion(usuario.getDireccion());
                    existingUsuario.setTelefonoMovil(usuario.getTelefonoMovil());
                    return toResponse(repositoryUsuarios.save(existingUsuario));
                })
                .orElse(null);
    }
}
